package org.firstinspires.ftc.teamcode;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantFunction;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;

public class linkage implements Action{
    Servo linkageRight,linkageLeft;
    double pozitie;
    public linkage(Servo lR, Servo lL, double poz){
        this.linkageRight=lR;
        this.linkageLeft=lL;
        this.pozitie=poz;
    }

    @Override
    public boolean run(@NonNull TelemetryPacket telemetryPacket) {
        linkageLeft.setPosition(pozitie);
        linkageRight.setPosition(pozitie);
        return false;
    }
}
