package org.firstinspires.ftc.teamcode;

public class Specifications {
    public static float moving_speed_teleop=1f;
    public static float highTicks=5000;
    public static int motorTicks=960;
    public  static float lowTicks=40;
    public static float closedPos=0.58f;
    public static float extendedPos=0.175f;

    public static float cotSus=0;
    public static float cotJos=0.48f;
    public static float pozPtMM=0.0018269230769231f;
    public static float incheietura_90_de_grade=0.1f;
    public static float inchietura_180_de_grade=0.72f;
    public static  float ghearaDeschisa=0.35f;
    public static float ghearaInchis=0.068f;
    public static float cotMijloc=0.2f;
    public static int ticksPerete= 820;
    public static int tickuriDeasupraSoecimen=200;
    public  static int tickuriIntrareSubmersibil=600;
    public static int tickuriRidicareSpecimen=50;
    public static int tickuriHighRung=3200;

    public static float putereGlisiere=1f;
}
