package org.firstinspires.ftc.teamcode;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantFunction;
import com.qualcomm.robotcore.hardware.DcMotor;

public class glisiere implements Action {
    DcMotor dreapta, stanga;
    int poz;


    public glisiere( DcMotor m1, DcMotor m2, int pozitie){
        this.dreapta=m2;
        this.stanga=m1;
        this.poz=pozitie;
    }

    @Override
    public boolean run(@NonNull TelemetryPacket telemetryPacket) {
        dreapta.setTargetPosition(poz);

        stanga.setTargetPosition(poz);
        dreapta.setPower(1);
        stanga.setPower(1);
        dreapta.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        stanga.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        return false;
    }
}
