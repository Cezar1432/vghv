package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.ColorSensor;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.OpticalDistanceSensor;

@TeleOp
public class teleOpPentruTeste extends LinearOpMode {


    DcMotorEx glisieraStanga,glisieraDreapta;
    ColorSensor senzor;
    public void inaltime_glisiere(int ticks){
        glisieraStanga.setTargetPosition(ticks);
        glisieraDreapta.setTargetPosition(ticks);
        glisieraDreapta.setPower(1);
        glisieraStanga.setPower(1);


    }
    public  void telemetrie(){
        telemetry.addData("Light Detected", ((OpticalDistanceSensor) senzor).getLightDetected());
        telemetry.addData("Rosu", senzor.red());
        telemetry.addData("Verde", senzor.green());
        telemetry.addData("Albastru", senzor.blue());
        telemetry.update();

    }
    @Override
    public void runOpMode() throws InterruptedException {

        glisieraStanga= hardwareMap.get(DcMotorEx.class, "glisieraLeft");
        glisieraDreapta= hardwareMap.get(DcMotorEx.class, "glisieraRight");

        senzor= hardwareMap.get(ColorSensor.class, "colorSensor");
        glisieraStanga.setDirection(DcMotorSimple.Direction.REVERSE);
        glisieraStanga.setTargetPosition(0);
        glisieraDreapta.setTargetPosition(0);
        glisieraDreapta.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        glisieraStanga.setMode(DcMotor.RunMode.RUN_TO_POSITION);

        waitForStart();

        while(opModeIsActive()){

            telemetrie();

        }





    }
}
