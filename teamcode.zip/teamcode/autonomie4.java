package org.firstinspires.ftc.teamcode;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.Trajectory;
import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.acmerobotics.roadrunner.TrajectoryActionBuilder;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous
public class autonomie4 extends LinearOpMode {
    // TODO: OMOARA L PE IORGA
    //TODO: DA FOC LA SEDIU SI OMOARA TOTI MEMBRII

    @Override
    public void runOpMode() throws InterruptedException {
        MecanumDrive drive= new MecanumDrive(hardwareMap, new Pose2d(24,-63.5,Math.toRadians(90)));
        ElapsedTime timerGlisiere;
        DcMotor glisieraRight,glisieraLeft;
        long nano=495762;
        Servo servoCot, servoCot2,servoGheara,servoIncheietura,linkageRight,linkageLeft;
        glisieraLeft=hardwareMap.dcMotor.get("glisieraLeft");
        glisieraRight=hardwareMap.dcMotor.get("glisieraRight");
        linkageRight=hardwareMap.servo.get("linkageRight");
        servoCot=hardwareMap.servo.get("servoCot");
        servoCot2=hardwareMap.servo.get("servoCot2");
        servoGheara=hardwareMap.servo.get("servoGheara");
        servoIncheietura=hardwareMap.servo.get("servoIncheietura");
        linkageLeft=hardwareMap.servo.get("linkageLeft");
        linkageRight.setDirection(Servo.Direction.REVERSE);
        glisieraLeft.setDirection(DcMotorSimple.Direction.REVERSE);
        Pose2d startPos = new Pose2d(24, -63.5 , Math.toRadians(90));


        TrajectoryActionBuilder tr1= drive.actionBuilder(startPos)
                .stopAndAdd(new servoFa(servoIncheietura, Specifications.incheietura_90_de_grade))
                .stopAndAdd(new servoFa(servoCot, Specifications.cotMijloc))
                .stopAndAdd(new servoFa(servoCot2,Specifications.cotMijloc))
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,Specifications.tickuriHighRung))
                .waitSeconds(0.2)

                .splineToConstantHeading(new Vector2d(9,-43), Math.toRadians(90))
                .splineToConstantHeading(new Vector2d(8,-38.15),Math.toRadians(90))
                .waitSeconds(0.5)
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,2060))
                .waitSeconds(nano*1140/1e9-0.15)
                .stopAndAdd(new servoFa(servoGheara,Specifications.ghearaDeschisa))
                .stopAndAdd(new servoFa(servoGheara,Specifications.ghearaDeschisa))
                .waitSeconds(0.1)
                .stopAndAdd(new servoFa(servoGheara, Specifications.ghearaDeschisa))
                .splineToConstantHeading(new Vector2d(12,-50),Math.toRadians(90))
                .splineToConstantHeading(new Vector2d(59,-61),Math.toRadians(90))
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight, -50))
                .waitSeconds(5);



        telemetry.addLine("gata ba da-i bataie");
        telemetry.update();

        timerGlisiere= new ElapsedTime();
        while(timerGlisiere.milliseconds()<100)
        {  glisieraLeft.setPower(1);
            glisieraRight.setPower(1);
        }

        glisieraLeft.setPower(0);
        glisieraRight.setPower(0);


        servoCot.setPosition(Specifications.cotJos);
        servoCot2.setPosition(Specifications.cotJos);
        servoGheara.setPosition(Specifications.ghearaInchis);
        servoIncheietura.setPosition(Specifications.inchietura_180_de_grade);
        linkageLeft.setPosition(Specifications.closedPos);
        linkageRight.setPosition(Specifications.closedPos);
        telemetry.addLine("gat ab da i bataie");
        //38.5
        //37
        //120
        waitForStart();
        while (opModeIsActive()) {
            Actions.runBlocking(tr1.build());
            requestOpModeStop();


        }
    }
}
