package org.firstinspires.ftc.teamcode;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantFunction;
import com.qualcomm.robotcore.hardware.Servo;

class servoFa implements Action{
    Servo servo;
    double poz;

    public servoFa(Servo s, double pozitie){

        this.servo=s;
        this.poz=pozitie;

    }


    @Override
    public boolean run(@NonNull TelemetryPacket telemetryPacket) {
        servo.setPosition(poz);
        return false;
    }
}