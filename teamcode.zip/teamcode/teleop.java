package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

@TeleOp
public class teleop extends LinearOpMode {
    ElapsedTime timerGlisiere2;
    DcMotor m[] = new DcMotor[6];
    ElapsedTime timerGlisiere;
    int directie;
    int pasCot=2;
    boolean dpadLeftPressed=false;
    boolean isRunning=false;
    ElapsedTime timpGlisiere;
    boolean okTest=false;
    Servo linkageLeft;
    Servo linkageRight;
    Servo servoCot;
    Servo servoCot2;
    Servo servoIncheietura;
    Servo servoGheara;
    Servo servotest;
    CRServo servoCarligLeft;
    CRServo servoCarligRight;
    boolean dintiDeschis =false;
    boolean pozParalela = true;
    int pasChestieAutomata=0;
    boolean ghearaJos=false;
    boolean linkageDeschis=false;
    boolean ok=false;

    double loopTime = 0;

    double linkageLastPosition;
    double incheituraLastPositon;
    ElapsedTime timerGheara = new ElapsedTime();
    ElapsedTime timerPoz= new ElapsedTime();
    ElapsedTime timerIncheietura= new ElapsedTime();
    ElapsedTime timerLinkage= new ElapsedTime();
    ElapsedTime timerAutomat= new ElapsedTime();
    ElapsedTime timerCot= new ElapsedTime();
    ElapsedTime timerCot2= new ElapsedTime();
    ElapsedTime timerGlisiereJos= new ElapsedTime();
    ElapsedTime timerAutomat2= new ElapsedTime();
    ElapsedTime timerRevenire= new ElapsedTime();
    long timpFinal;
    private void movement(float forward, float strafe, float rotation) {
        // power applied to the robot wheel by wheel
        double[] power = new double[4];
        rotation *= -1;
        power[0] = (-forward + strafe + rotation) * Specifications.moving_speed_teleop;   //+
        power[1] = (+forward + strafe + rotation) * Specifications.moving_speed_teleop;   //-
        power[2] = (-forward - strafe + rotation) * Specifications.moving_speed_teleop;   //-
        power[3] = (+forward - strafe + rotation) * Specifications.moving_speed_teleop;   //+

        // applying the power
        if(gamepad1.left_trigger>0.5)
        {
            m[0].setPower(power[0]/4);
            m[1].setPower(power[1]/4);
            m[2].setPower(power[2]/4);
            m[3].setPower(power[3]/4);
        }
        else {
            m[0].setPower(power[0]);
            m[1].setPower(power[1]);
            m[2].setPower(power[2]);
            m[3].setPower(power[3]);
        }
    }


    public DcMotor initMotoare(String name, int hasEncoder) {
        DcMotor motor;

        motor = hardwareMap.dcMotor.get(name);

        motor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        if (hasEncoder == 1) {
            motor.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        } else {
            motor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        }

        return motor;

    }

    public Servo initServo(String name) {
        Servo servo;
        servo = hardwareMap.servo.get(name);

        return servo;
    }
   /* public void inaltime_glisiere(int ticks4, int ticks5, boolean ok){


        if(m[4].getCurrentPosition()>ticks4 && m[5].getCurrentPosition()>ticks5)
            directie=-1;
        else if(m[4].getCurrentPosition()<ticks4 && m[5].getCurrentPosition()<ticks5)
            directie=1;
        if(ok== false)
        {
            m[4].setPower(Specifications.putereGlisiere*directie);
            m[5].setPower(Specifications.putereGlisiere*directie);
        }
        else if(ok==true)
        {
            m[4].setPower(directie);
            m[5].setPower(directie);
        }

        if(ticks4<50)
            m[4].setTargetPosition(-50);
        else
        if(ticks4>5830)
            m[4].setTargetPosition(5830);
        else m[4].setTargetPosition(ticks4);


        if(ticks5<50)
            m[5].setTargetPosition(-50);
        else
        if(ticks5>5830)
            m[5].setTargetPosition(5830);

        else
            m[5].setTargetPosition(ticks5);


        m[4].setMode(DcMotor.RunMode.RUN_TO_POSITION);
        m[5].setMode(DcMotor.RunMode.RUN_TO_POSITION);

    }*/


    public void glisiere_var_3(){
        if(gamepad2.right_stick_y>0.3){
reinventez_roata(m[4].getCurrentPosition()-100);        }
        if(gamepad2.right_stick_y<-0.3){
reinventez_roata(m[4].getCurrentPosition()+100);        }
    }
    public void glisiere_orizonatale()
    {
        if(gamepad2.dpad_right  && timerLinkage.milliseconds()>250){
            if(linkageDeschis==false){
                linkageDeschis=true;
                linkageRight.setPosition(Specifications.extendedPos);
                linkageLeft.setPosition(Specifications.extendedPos);
            }
            else {
                linkageDeschis=false;
                linkageRight.setPosition(Specifications.closedPos);
                linkageLeft.setPosition(Specifications.closedPos);
            }
            timerLinkage.reset();
        }
        linkageLeft.setPosition(linkageLeft.getPosition()+0.0025*gamepad2.left_trigger);
        linkageRight.setPosition(linkageRight.getPosition()+0.0025* gamepad2.left_trigger);
        linkageLeft.setPosition(linkageLeft.getPosition()-0.0025*gamepad2.right_trigger);
        linkageRight.setPosition(linkageRight.getPosition()-0.0025* gamepad2.right_trigger);

    }

    boolean deschis;

    public void setServoGheara()
    {
        if(gamepad2.a && timerGheara.milliseconds()>300)
        {
            if(deschis==false)
            {servoGheara.setPosition(Specifications.ghearaDeschisa); deschis=true;}
            else { servoGheara.setPosition(Specifications.ghearaInchis); deschis=false;}
            timerGheara.reset();
        }
    }
    public void cotInSus(){

        if(gamepad2.b && timerCot.milliseconds()>150)
        {
            if(pasCot==1)
            {
                pasCot=2;
                servoCot.setPosition(Specifications.cotMijloc);
                servoCot2.setPosition(Specifications.cotMijloc);

            }
            else if(pasCot==2)
            {
                pasCot=3;
                servoCot.setPosition(Specifications.cotSus);
                servoCot2.setPosition(Specifications.cotSus);

            }
            timerCot.reset();
        }
    }
    public void cotInJos(){
        if(gamepad2.square && timerCot2.milliseconds()>150){
            if(pasCot==3){
                pasCot=2;
                servoCot.setPosition(Specifications.cotMijloc);
                servoCot2.setPosition(Specifications.cotMijloc);


            }
            else if(pasCot==2){
                pasCot=1;
                servoCot.setPosition(Specifications.cotJos);
                servoCot2.setPosition(Specifications.cotJos);

            }
            timerCot2.reset();
        }
    }
    public void ceva_chestie_automata_partea_0(){
        if(gamepad2.right_stick_button){
            linkageLastPosition=linkageRight.getPosition();
            incheituraLastPositon=servoIncheietura.getPosition();

reinventez_roata(0);
timerGlisiereJos.reset();
        }
    }

    public void setServoCot(){
        cotInSus();
        cotInJos();


        servoCot.setPosition(servoCot.getPosition()+0.0025* gamepad2.left_stick_y);
        servoCot2.setPosition(servoCot.getPosition()+0.0025* gamepad2.left_stick_y);
    }
    public void ceva_chestie_automata(){

        servoGheara.setPosition(Specifications.ghearaInchis);
        deschis=false;
        timerAutomat.reset();


    }
    public void revenire(){
        timerRevenire.reset();
        if(gamepad2.left_bumper){
reinventez_roata(200);            linkageRight.setPosition(Specifications.extendedPos);
            linkageLeft.setPosition(Specifications.extendedPos);
            linkageDeschis=true;

        }
    }
    public void revenirePartea2(){
        servoIncheietura.setPosition(incheituraLastPositon);
        servoCot2.setPosition(Specifications.cotJos);
        servoCot.setPosition(Specifications.cotJos);
        pasCot=1;
        servoGheara.setPosition(Specifications.ghearaDeschisa);
        deschis=true;
    }

    public void setServoIncheietura(){
        if(gamepad2.triangle && timerIncheietura.milliseconds()>300){
            if(pozParalela== false) {
                pozParalela = true;
                servoIncheietura.setPosition(Specifications.inchietura_180_de_grade);
            }
            else
            {
                pozParalela=false;
                servoIncheietura.setPosition(Specifications.incheietura_90_de_grade);
            }
            timerIncheietura.reset();

        }

    }
    public void glisisereJosAutomatPartea1(){


    }
    public void ceva_chestie_automata_partea_2(){
    reinventez_roata(600);
    servoCot.setPosition(Specifications.cotMijloc);
        servoCot2.setPosition(Specifications.cotMijloc);
        pasCot=2;
        linkageRight.setPosition(Specifications.closedPos);
        linkageLeft.setPosition(Specifications.closedPos);
        linkageDeschis=false;
        servoIncheietura.setPosition(Specifications.incheietura_90_de_grade);
        pozParalela=true;

    }
    public void glisisereJosAutomatPartea0(){
        if(gamepad2.dpad_down){
            servoCot.setPosition(Specifications.cotJos);
            servoCot2.setPosition(Specifications.cotJos);
            pasCot=1;
            servoIncheietura.setPosition(Specifications.incheietura_90_de_grade);
            pozParalela=false;
            servoGheara.setPosition(Specifications.ghearaDeschisa);
            deschis=true;
            timerAutomat2.reset();

reinventez_roata(600);        }

    }
    public void perete(){
        if(gamepad2.dpad_left){
reinventez_roata(Specifications.ticksPerete-200);        }
    }
    public void glisiereHighRung(){
        if(gamepad2.left_stick_button){
reinventez_roata(3500);        }
    }
    public void maAruncDeLaGeam(){
        if(gamepad2.right_bumper){
reinventez_roata(200);        }
    }

    public void agatare()
    {

        if (gamepad1.dpad_left) {
            if (!dpadLeftPressed) {
                dpadLeftPressed = true;
                if (isRunning) {
                    {
                        servoCarligLeft.setPower(0f);
                        servoCarligRight.setPower(0f);
                    }
                } else {
                    servoCarligLeft.setPower(1f);
                    servoCarligRight.setPower(1f);
                }
                isRunning = !isRunning;
            }
        } else {
            dpadLeftPressed = false;
        }

    }


    public void glisiereHighBasket(){
        if(gamepad2.dpad_up){
reinventez_roata(5830);            servoCot.setPosition(Specifications.cotSus);
            servoCot2.setPosition(Specifications.cotSus);
            pasCot=3;

        }
    }
    public void reinventez_roata(int ticks){
        if(ticks<0){
            m[4].setTargetPosition(-50);
            m[5].setTargetPosition(-50);
        }
        else if(ticks>5830){
            m[4].setTargetPosition(5830);
            m[5].setTargetPosition(5830);
        }
         else {
            m[4].setTargetPosition(ticks);
            m[5].setTargetPosition(ticks);
        }
        m[4].setPower(1);
        m[5].setPower(1);

    }

    public  void telemetrie(){

        double loop = System.nanoTime();

        telemetry.addData("hz", 1000000000/ (loopTime - loop));


        telemetry.addData("linkageLeft: ", linkageLeft.getPosition());
        telemetry.addData("linkageRight: ", linkageRight.getPosition());
        telemetry.addData("m4/glisieraLeft", m[4].getCurrentPosition());
        telemetry.addData("m5/glisieraRight", m[5].getCurrentPosition());
        telemetry.addData("servoCot", servoCot.getPosition());
        telemetry.addData("servoCot2", servoCot2.getPosition());

        telemetry.addData("servoIncheietura", servoIncheietura.getPosition());
        telemetry.addData("servoGheara", servoGheara.getPosition());
        telemetry.addData("Right Stick Y:", gamepad2.right_stick_y);
        telemetry.addData("timp final", timpFinal);

        telemetry.update();
        loopTime=loop;
    }

    @Override
    public void runOpMode() throws InterruptedException {

        m[0]=initMotoare("mBackRight", 0);
        m[1]=initMotoare("mBackLeft", 0);
        m[2]=initMotoare("mFrontRight", 0);
        m[3]=initMotoare("mFrontLeft", 0);
        m[4]=initMotoare("glisieraLeft", 1);
        m[5]=initMotoare("glisieraRight", 1);
        linkageLeft=initServo("linkageLeft");
        linkageRight=initServo("linkageRight");
        servoCot=initServo("servoCot");
        servoCot2=initServo("servoCot2");
        servoGheara=initServo("servoGheara");
        servoIncheietura=initServo("servoIncheietura");
        servoCarligLeft=hardwareMap.crservo.get("servoCarligLeft");
        servoCarligRight=hardwareMap.crservo.get("servoCarligRight");
        linkageRight.setDirection(Servo.Direction.REVERSE);
        m[4].setDirection(DcMotorSimple.Direction.REVERSE);
        m[4].setTargetPosition(0);
        m[5].setTargetPosition(0);
        m[4].setMode(DcMotor.RunMode.RUN_TO_POSITION);
        m[5].setMode(DcMotor.RunMode.RUN_TO_POSITION);


        telemetry.speak("dobre, sa mi iei carasul in gura");
        telemetry.update();


        waitForStart();
        timerGlisiere2= new ElapsedTime();
        while(opModeIsActive()){
            movement(gamepad1.left_stick_y, gamepad1.left_stick_x, gamepad1.right_stick_x);

            agatare();
            ceva_chestie_automata_partea_0();
            glisiere_orizonatale();
            glisiere_var_3();
            setServoCot();
            setServoGheara();
            setServoIncheietura();
            glisiereHighBasket();
            glisiereHighRung();
            revenire();
            glisisereJosAutomatPartea0();
            if(timerAutomat2.milliseconds()>2600 && timerAutomat2.milliseconds()<2610){
                glisisereJosAutomatPartea1();
            }
            if(timerGlisiereJos.milliseconds()>300 && timerGlisiereJos.milliseconds()<310)
                ceva_chestie_automata();
            if(timerAutomat.milliseconds()>200 && timerAutomat.milliseconds()<210)
                ceva_chestie_automata_partea_2();
            perete();
            if(timerRevenire.milliseconds()>400 && timerRevenire.milliseconds()<410)
                revenirePartea2();
            maAruncDeLaGeam();
            telemetrie();


        }

    }

}
