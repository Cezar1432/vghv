package org.firstinspires.ftc.teamcode;

public class co {
    public static final String FRONT_LEFT_MOTOR = "frontLeft";
    public static final String FRONT_RIGHT_MOTOR = "frontRight";
    public static final String BACK_LEFT_MOTOR = "backLeft";
    public static final String BACK_RIGHT_MOTOR = "backRight";
    public static final String DISTANCE_SENSOR = "range_sensor";
    public static final String MOTOR_LIFT = "motor_lift";
    public static final String SERVO_BASE = "servo_base";
    public static final String SERVO_MID = "servo_mid";
    public static final String SERVO_CLAMP = "servo_clamp";
    public static final double STRAFE_ADJUSTMENT = 1.5;
    public static final double RAMP_SPEED = 0.05;
    public static final double STATIC_SPEED=0.2;

}
