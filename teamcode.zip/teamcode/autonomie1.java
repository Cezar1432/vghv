package org.firstinspires.ftc.teamcode;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.Trajectory;
import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.Servo;
import com.acmerobotics.roadrunner.TrajectoryActionBuilder;
import com.qualcomm.robotcore.util.ElapsedTime;

@Autonomous
public class autonomie1 extends LinearOpMode {
    // TODO: OMOARA L PE IORGA
    //TODO: DA FOC LA SEDIU SI OMOARA TOTI MEMBRII

    @Override
    public void runOpMode() throws InterruptedException {
        ElapsedTime timerGlisiere;
        MecanumDrive drive= new MecanumDrive(hardwareMap, new Pose2d(24,63.5,Math.toRadians(-90)));

        DcMotor glisieraRight,glisieraLeft;
        long nano=458000;
        Servo servoCot, servoCot2,servoGheara,servoIncheietura,linkageRight,linkageLeft;
        glisieraLeft=hardwareMap.dcMotor.get("glisieraLeft");
        glisieraRight=hardwareMap.dcMotor.get("glisieraRight");
        linkageRight=hardwareMap.servo.get("linkageRight");
        servoCot=hardwareMap.servo.get("servoCot");
        servoCot2=hardwareMap.servo.get("servoCot2");
        servoGheara=hardwareMap.servo.get("servoGheara");
        servoIncheietura=hardwareMap.servo.get("servoIncheietura");
        linkageLeft=hardwareMap.servo.get("linkageLeft");
        linkageRight.setDirection(Servo.Direction.REVERSE);
        glisieraLeft.setDirection(DcMotorSimple.Direction.REVERSE);
        Pose2d startPos = new Pose2d(24, 63.5 , Math.toRadians(-90));


        TrajectoryActionBuilder tr1= drive.actionBuilder(startPos)
                /*.splineToConstantHeading(new Vector2d(6,40), Math.toRadians(-90))
                .waitSeconds(1)
                .turnTo(Math.toRadians(90))
                .stopAndAdd(new servoFa(servoGheara, Specifications.ghearaDeschisa))
                .stopAndAdd(new servoFa(servoCot, Specifications.cotJos))
                .stopAndAdd(new servoFa(servoCot2, Specifications.cotJos))



                .splineTo(new Vector2d(48.27, 41.01), Math.toRadians(-90))
                .waitSeconds(1)
                .stopAndAdd(new servoFa(servoCot, Specifications.cotSus))
                .stopAndAdd(new servoFa(servoCot, Specifications.cotSus))

                .turn(Math.toRadians(180))
                .splineTo(new Vector2d(52,55), Math.toRadians(57))
                .waitSeconds(1)
                .stopAndAdd(new servoFa(servoCot,Specifications.cotJos))
                .stopAndAdd(new servoFa(servoCot2, Specifications.cotJos))
                .turn(Math.toRadians(-125))
                .splineTo(new Vector2d(55.84, 41.01), Math.toRadians(-92))
                .waitSeconds(1)
                .stopAndAdd(new servoFa(servoCot, Specifications.cotSus))
                .stopAndAdd(new servoFa(servoCot2, Specifications.cotSus))

                .turn(Math.toRadians(180))
                .splineTo(new Vector2d(50,53), Math.toRadians(60))
                .waitSeconds(1)
                .stopAndAdd(new servoFa(servoCot,Specifications.cotJos))
                .stopAndAdd(new servoFa(servoCot2,Specifications.cotJos))
                .stopAndAdd(new servoFa(servoIncheietura, Specifications.inchietura_180_de_grade))
                .turn(Math.toRadians(180))
                .splineTo(new Vector2d(47.08, 42.18), Math.toRadians(-90))
                .splineTo(new Vector2d(59.67, 27.6), Math.toRadians(20))
                .waitSeconds(1)
                .stopAndAdd(new servoFa(servoCot, Specifications.cotSus))
                .stopAndAdd(new servoFa(servoCot2, Specifications.cotSus))

                .turn(Math.toRadians(90))
                .splineTo(new Vector2d(46,52),Math.toRadians(63));*/
                .stopAndAdd(new servoFa(servoIncheietura, Specifications.incheietura_90_de_grade))

                .stopAndAdd(new servoFa(servoCot, Specifications.cotMijloc))
                .stopAndAdd(new servoFa(servoCot2,Specifications.cotMijloc))
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,Specifications.tickuriHighRung))
                .waitSeconds(0.2)

                //.waitSeconds(495762.2*1500/1e9+0.3)
                     .splineToConstantHeading(new Vector2d(11,41.5), Math.toRadians(-90))

                .splineToConstantHeading(new Vector2d(12,39),Math.toRadians(-90))
                .waitSeconds(0.5)
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,2060))
                .waitSeconds(nano*1140/1e9-0.15)
                .stopAndAdd(new servoFa(servoGheara, Specifications.ghearaDeschisa))
                .stopAndAdd(new servoFa(servoGheara, Specifications.ghearaDeschisa))
                        .waitSeconds(0.2)
                .stopAndAdd(new servoFa(servoGheara, Specifications.ghearaDeschisa))
                .turnTo(Math.toRadians(45))
                .waitSeconds(0.1)
                .splineTo(new Vector2d(49.5, 37), Math.toRadians(-86))
                .waitSeconds(0.5)
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,1885))
                .turnTo(Math.toRadians(-90))
                .stopAndAdd(new servoFa(servoCot,Specifications.cotSus))
                .stopAndAdd(new servoFa(servoCot2,Specifications.cotSus))
                .splineTo(new Vector2d(22,13), Math.toRadians(172))
                .stopAndAdd(new servoFa(servoCot,0.08f))
                .stopAndAdd(new servoFa(servoCot2,0.08f))
                .waitSeconds(5);


               /* .turnTo(Math.toRadians(90))
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight, 200))
                .stopAndAdd(new servoFa(servoCot, Specifications.cotJos))
                .stopAndAdd(new servoFa(servoCot2, Specifications.cotJos))



                .splineTo(new Vector2d(48.27, 36.81), Math.toRadians(-93))
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,50))
                .waitSeconds(nano*150/1e9+0.05)
                .stopAndAdd(new servoFa(servoGheara,Specifications.ghearaInchis)
                .stopAndAdd(new servoFa(servoCot, Specifications.cotSus))
                .stopAndAdd(new servoFa(servoCot2, Specifications.cotSus))
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,6100))


                .turn(Math.toRadians(180))
                .splineTo(new Vector2d(52,55), Math.toRadians(57))
                .waitSeconds(0.1)
                .stopAndAdd(new linkage(linkageLeft,linkageRight,linkageLeft.getPosition()-50*Specifications.pozPtMM))
                .waitSeconds(0.1)
                .stopAndAdd(new servoFa(servoGheara,Specifications.ghearaDeschisa))
                .waitSeconds(0.02)
                .stopAndAdd(new linkage(linkageLeft,linkageRight,linkageLeft.getPosition()+50*Specifications.pozPtMM))

                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,200))
                .stopAndAdd(new servoFa(servoCot,Specifications.cotJos))
                .stopAndAdd(new servoFa(servoCot2, Specifications.cotJos))
                .turn(Math.toRadians(-125))
                .splineTo(new Vector2d(54.84, 36.81), Math.toRadians(-95))
                .waitSeconds(0.1)
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,50))
                .waitSeconds(0.05)
                .stopAndAdd(new servoFa(servoGheara, Specifications.ghearaInchis))
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,6100))
                .stopAndAdd(new servoFa(servoCot, Specifications.cotSus))
                .stopAndAdd(new servoFa(servoCot2, Specifications.cotSus))

                .turn(Math.toRadians(180))
                .splineTo(new Vector2d(50,53), Math.toRadians(50))
                .waitSeconds(0.001)
                .stopAndAdd(new linkage(linkageLeft,linkageRight,linkageLeft.getPosition()-80*Specifications.pozPtMM))
                .stopAndAdd(new servoFa(servoGheara,Specifications.ghearaDeschisa))
                .waitSeconds(0.01)
                .stopAndAdd(new linkage(linkageLeft,linkageRight,linkageLeft.getPosition()+80*Specifications.pozPtMM))
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,200))
                .stopAndAdd(new servoFa(servoCot,Specifications.cotJos))
                .stopAndAdd(new servoFa(servoCot2,Specifications.cotJos))
                .stopAndAdd(new servoFa(servoIncheietura, Specifications.inchietura_180_de_grade))
                .turn(Math.toRadians(180))
                .splineTo(new Vector2d(47.08, 42.18), Math.toRadians(-90))
                .splineTo(new Vector2d(61.17, 29.6), Math.toRadians(20))
                .stopAndAdd(new linkage(linkageLeft,linkageRight, linkageLeft.getPosition()-25*Specifications.pozPtMM))
                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,50))
                .stopAndAdd(new servoFa(servoGheara,Specifications.ghearaInchis))

                .stopAndAdd(new glisiere(glisieraLeft,glisieraRight,6100))
                .stopAndAdd(new servoFa(servoCot, Specifications.cotSus))
                .stopAndAdd(new servoFa(servoCot2, Specifications.cotSus))

                .turn(Math.toRadians(90))
                .splineTo(new Vector2d(46,52),Math.toRadians(63))
                .waitSeconds(0.01)
                .stopAndAdd(new linkage(linkageLeft,linkageRight,linkageLeft.getPosition()-60*Specifications.pozPtMM))
                        .waitSeconds(0.1)
                                .stopAndAdd(new servoFa(servoGheara,Specifications.ghearaDeschisa));*/




        telemetry.addLine("gata ba da-i bataie");
        telemetry.update();
        timerGlisiere= new ElapsedTime();
        while(timerGlisiere.milliseconds()<100)
        {  glisieraLeft.setPower(1);
            glisieraRight.setPower(1);
        }

        glisieraLeft.setPower(0);
        glisieraRight.setPower(0);


        servoCot.setPosition(Specifications.cotJos);
        servoCot2.setPosition(Specifications.cotJos);
        servoGheara.setPosition(Specifications.ghearaInchis);
        servoIncheietura.setPosition(Specifications.inchietura_180_de_grade);
        linkageLeft.setPosition(Specifications.closedPos);
        linkageRight.setPosition(Specifications.closedPos);
        //38.5
        //37
        //120
        waitForStart();
        while (opModeIsActive()) {
            Actions.runBlocking(tr1.build());
            requestOpModeStop();


        }
    }
}
