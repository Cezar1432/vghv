package org.firstinspires.ftc.teamcode;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.InstantFunction;
import com.qualcomm.robotcore.hardware.DcMotor;

public class glisiereCareNuSeGrabesc implements Action {
    DcMotor dreapta, stanga;
    int poz;
    int putere;

    public glisiereCareNuSeGrabesc( DcMotor m1, DcMotor m2, int pozitie){
        this.dreapta=m2;
        this.stanga=m1;
        this.poz=pozitie;
    }

    @Override
    public boolean run(@NonNull TelemetryPacket telemetryPacket) {

        if(poz> dreapta.getCurrentPosition())
            putere=1;
        else if(poz<dreapta.getCurrentPosition())
            putere=-1;
        while(dreapta.getCurrentPosition()!=poz)
        {
            dreapta.setPower(putere);
            stanga.setPower(putere);
        }
        dreapta.setPower(0);
        stanga.setPower(0);


        return false;
    }
}
